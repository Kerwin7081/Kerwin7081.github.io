Hong Kong IPO Research | Kerwin / Enya
Price cutoff: 2026-10-02; publication: 2026-10-04.
115 fundraising IPOs; 35 primary cornerstone records; 1,067 vendor records; 11,157 daily observations.
Returns adjust stock bonuses/splits, exclude cash dividends and fees.
Vendor dates are estimates unless marked primary-verified. Unlock returns are theoretical marks, not actual sales.
Daily close/volume use 2026-10-02 share basis; raw_close/raw_volume retain original share basis. turnover_hkd is exchange reported where available; turnover_proxy_hkd is close*volume estimate.
02649 halted at cutoff: reference mark 3.90 HKD, not tradable.
Full methods and source links: https://enyaclawd.com/hk-ipo-fundraising-returns-liquidity-20261004/
